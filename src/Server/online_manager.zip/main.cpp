#include<iostream>
#include<fstream>
#include"TcpServer.h"
#include "udp_client.h"
#include "udp_server.h"
#pragma comment(lib, "Ws2_32.lib")
int main() {
	std::ifstream passfile("password.txt");
	if (!passfile) {
		std::cout << "�ļ���ʱʧ��";
		exit(1);
	}
	Server server;
	server.StartReceiverThread();
	Client client;
	client.ClientBroadcast(8888);
	server.StopReceiverThread();
	server.SendOfflineMessage();
	std::string password;
	passfile >> password;
	TcpServer myServer(password);
	myServer.EventListen();
}